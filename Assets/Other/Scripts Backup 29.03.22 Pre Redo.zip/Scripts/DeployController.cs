using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeployController : MonoBehaviour
{

    void Update()
    {
        //CheckCollisions();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "New Player")
        {
            Debug.Log("I have collided with: " + collision.gameObject.name + " and am ready to enter the powerloader");
            GameManager.Instance.isPlayerNearPowerloader = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.name == "New Player")
        {
            Debug.Log("They player is no longer in range and cannot deploy");
            GameManager.Instance.isPlayerNearPowerloader = false;
        }
    }

    /*
    public void CheckCollisions()
    {
        bool isTouchingWall = this.GetComponent<Collider2D>().IsTouchingLayers(LayerMask.GetMask("Default"));
        if (isTouchingWall)
        { Debug.Log("I am currently touching something"); }
    }
    */
}
