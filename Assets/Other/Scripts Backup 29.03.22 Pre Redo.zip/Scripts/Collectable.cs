using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectable : MonoBehaviour
{
    enum ItemType { Coin, Health, Ammo, InventoryItem } //Creats an ItemType enum (drop down box to select specific option).

    [Header("Attributes")]
    [SerializeField] private ItemType itemType;

    [Header("Audio")]
    [SerializeField] private AudioClip soundCollection;
    [SerializeField] private float soundCollectionVolume = 1;

    [Header("References")]
    [SerializeField] private string inventoryStringName;
    [SerializeField] private Sprite inventorySprite;
    [SerializeField] private ParticleSystem particleCollectableSpark;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //If I have collided with the player, check what item-type I am and then carry out that item-type's function. Then update the UI and destroy me. 
        if (collision.gameObject == NewPlayer.Instance.gameObject)
        {
            if (particleCollectableSpark)
            {
                particleCollectableSpark.transform.parent = null;
                particleCollectableSpark.gameObject.SetActive(true);
                Destroy(particleCollectableSpark.gameObject, particleCollectableSpark.main.duration);
            }

            if (itemType == ItemType.Coin)
            { 
                NewPlayer.Instance.coinsCollected += 1;
                NewPlayer.Instance.sfxAudioSource.PlayOneShot(soundCollection, soundCollectionVolume);
            }

            else if (itemType == ItemType.Health)
            {
                NewPlayer.Instance.sfxAudioSource.PlayOneShot(soundCollection, soundCollectionVolume);
                if (NewPlayer.Instance.health < 100)
                { NewPlayer.Instance.health += 5; }
            }

            else if (itemType == ItemType.Ammo)
            { }

            else if (itemType == ItemType.InventoryItem)
            { 
                NewPlayer.Instance.AddInventoryItem(inventoryStringName, inventorySprite);
                NewPlayer.Instance.sfxAudioSource.PlayOneShot(soundCollection, soundCollectionVolume);
            }

            NewPlayer.Instance.UpdateUI();
            Destroy(gameObject);
        }
    }
}
