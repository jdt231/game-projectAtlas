using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    //Singleton instantiation
    private static GameManager instance;
    public static GameManager Instance
    {
        get
        {
            if (instance == null) instance = GameObject.FindObjectOfType<GameManager>();
            return instance;
        }
    }

    [Header("References")]
    public Text coinsText;
    public Text batteriesText;
    public Image healthBar;
    public Image energyBar;
    public Image inventoryItemImage;
    public Animator uiAnimator;

    public PowerloaderController powerloader;
    [SerializeField] public bool isPlayerInPowerloader = false;
    [SerializeField] public bool isPlayerNearPowerloader = false;

    public bool frozen = false;

    private void Awake()
    {
        if (GameObject.Find("New Game Manager"))
        { Destroy(gameObject); }
    }

    // Start is called before the first frame update
    void Start()
    {
        DontDestroyOnLoad(gameObject);
        gameObject.name = "New Game Manager";
    }

    // Update is called once per frame
    void Update()
    {
        ProcessKeyPress();
    }

    private void ProcessKeyPress()
    {
        if ((Input.GetKeyDown(KeyCode.Keypad9)))
        {
            if (isPlayerInPowerloader == false && isPlayerNearPowerloader == true)
            {
                PlayerEnterPowerloader();
            }

            else if (isPlayerInPowerloader == false && isPlayerNearPowerloader == false)
            {
                Debug.Log("Out of range of powerloader, cannot deploy");
            }

            else if (isPlayerInPowerloader == true)
            {
                PlayerExitPowerloader();
            }
        }
    }

    public void PlayerEnterPowerloader()
    {
        NewPlayer.Instance.GetComponent<CapsuleCollider2D>().enabled = false;
        isPlayerInPowerloader = true;

        powerloader.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;

        powerloader.repairPosition.SetActive(true);
        powerloader.deployPosition.gameObject.SetActive(false);
    }

    public void PlayerExitPowerloader()
    {
        NewPlayer.Instance.GetComponent<CapsuleCollider2D>().enabled = true;
        isPlayerInPowerloader = false;

        powerloader.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic;

        powerloader.repairPosition.SetActive(false);
        powerloader.deployPosition.SetActive(true);

        NewPlayer.Instance.transform.position = powerloader.deployPosition.transform.position;
    }
}
