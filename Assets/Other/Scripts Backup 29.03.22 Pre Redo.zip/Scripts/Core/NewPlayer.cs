using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;

public class NewPlayer : PhysicsObject
{
    //Singleton instantiation
    private static NewPlayer instance;
    public static NewPlayer Instance
    {
        get
        {
            if (instance == null) instance = GameObject.FindObjectOfType<NewPlayer>();
            return instance;
        }
    }

    [Header("Attributes")]
    [SerializeField] private float attackDuration = 0.5f; //how long is the attack box active when attacking
    public int attackPower = 25;
    [SerializeField] private float jumpPower = 10f;
    [SerializeField] private float maxSpeed = 1f;
    [SerializeField] private AudioClip deathSound;
    //public bool frozen = false; // Moved to GameManager. Delete once sure not needed here.
    [SerializeField] private float fallForgiveness = 1; // This is the amount of seconds the player has after falling from a ledge to jump.
    [SerializeField] private float fallForgivenessCounter; // This is the simple counter that will begin the moment the player falls from a ledge.
    private float launch;
    [SerializeField] private float launchRecovery;
    [SerializeField] private Vector2 launchPower;

    [Header("Inventory")]
    public int ammo;
    public int coinsCollected;
    public int health = 100;
    public int energy = 100;
    private int maxHealth = 100;
    private int maxEnergy = 100;

    [Header("References")]
    [SerializeField] private Animator animator;
    [SerializeField] private AnimatorFunctions animatorFunctions;
    [SerializeField] private GameObject attackBox;
    [SerializeField] public CameraEffects cameraEffects;
    public Dictionary<string, Sprite> inventory = new Dictionary<string, Sprite>(); //dictionary storing all inventory item strings
    [Tooltip("The default inventory item slot")]
    public Sprite inventoryItemBlank;
    [Tooltip("The default (white) key item")]
    public Sprite keySprite;
    [Tooltip("The gem (coloured) key item")]
    public Sprite keyGemSprite;
    private Vector2 healthBarOrigSize;
    private Vector2 energyBarOrigSize;

    public AudioSource sfxAudioSource;
    public AudioSource musicAudioSource;
    public AudioSource ambienceAudioSource;

    public CompanionController companion;
    public GameObject powerLoader;

    private void Awake()
    {
        if (GameObject.Find("New Player"))
        { Destroy(gameObject); }
    }

    // Start is called before the first frame update
    void Start()
    {
        DontDestroyOnLoad(gameObject);
        gameObject.name = "New Player";

        SetSpawnPosition();

        healthBarOrigSize = GameManager.Instance.healthBar.rectTransform.sizeDelta;
        energyBarOrigSize = GameManager.Instance.energyBar.rectTransform.sizeDelta;
        UpdateUI();
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.Instance.frozen == false & GameManager.Instance.isPlayerInPowerloader == false)
        {
            ControlVelocity();
            ControlLocalScale();
            ControlAttacking();
            ControlDeath();
        }
        else
        {
            targetVelocity = new Vector2(0, 0);
            SetPositionToPowerloader();
        }

        //Set each animator float, bool & trigger so it knows which animation to fire
        //animator.SetFloat("velocityX", Mathf.Abs(velocity.x) / maxSpeed);
        //animator.SetFloat("velocityY", velocity.y);
        animator.SetBool("grounded", grounded);
        //animator.SetFloat("attackDirectionY", Input.GetAxis("Vertical"));
    }

    private void SetPositionToPowerloader()
    {
        if (GameManager.Instance.isPlayerInPowerloader)
        {
            this.transform.position = new Vector3(powerLoader.transform.position.x, powerLoader.transform.position.y, powerLoader.transform.position.z);
        }
    }

    public void SetSpawnPosition()
    {
        transform.position = GameObject.Find("Spawn Location").transform.position;
    }

    public void UpdateUI()
    {
        //if the healthbar's original size has not been set yet, match it to the healthbar rectTransform size.
        if (healthBarOrigSize == Vector2.zero) healthBarOrigSize = GameManager.Instance.healthBar.rectTransform.sizeDelta;
        if (energyBarOrigSize == Vector2.zero) energyBarOrigSize = GameManager.Instance.energyBar.rectTransform.sizeDelta;
        GameManager.Instance.coinsText.text = ("COINS: " + coinsCollected.ToString());
        GameManager.Instance.batteriesText.text = ("BATTS: " + companion.inventoryBatteries.ToString());

        //Set the health bar width to a percentage of its original value
        GameManager.Instance.healthBar.rectTransform.sizeDelta = new Vector2(healthBarOrigSize.x * ((float)health / (float)maxHealth), GameManager.Instance.healthBar.rectTransform.sizeDelta.y);
        GameManager.Instance.energyBar.rectTransform.sizeDelta = new Vector2(energyBarOrigSize.x * ((float)energy / (float)maxEnergy), GameManager.Instance.energyBar.rectTransform.sizeDelta.y);
    }

    private void ControlVelocity()
    {
        //Lerp (ease) the launch value back to zero at all times.
        launch += (0 - launch) * Time.deltaTime * launchRecovery;

        targetVelocity = new Vector2(Input.GetAxis("Horizontal") * maxSpeed + launch, 0);

        //if the player is no longer grounded, begin counting the fallForgivenessCounter
        if (!grounded)
        { fallForgivenessCounter += Time.deltaTime; }
        else
        { fallForgivenessCounter = 0; }

        //if the player presses "Jump" and we are grounded, set the velocity to a jump power value.
        if (Input.GetButtonDown("Jump") && fallForgivenessCounter < fallForgiveness)
        {
            Debug.Log("Player is trying to jump");
            animator.SetTrigger("jump"); // New jump functionality attempt

            velocity.y = jumpPower;
            grounded = false;
            fallForgivenessCounter = fallForgiveness;
        }
    }

    private void ControlLocalScale()
    {
        //flip the player's localscale.x if the move speed is greater than .01 of less than -01
        if (targetVelocity.x < -0.01)
        {
            transform.localScale = new Vector2(-1, 1);
        }
        else if (targetVelocity.x > 0.01)
        {
            transform.localScale = new Vector2(1, 1);
        }
    }

    private void ControlAttacking()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            animator.SetTrigger("attack");
        }
    }

    private void ControlDeath()
    {
        if (health <= 0)
        {
            StartCoroutine(Die());
        }
    }

    public IEnumerator Die()
    {
        GameManager.Instance.frozen = true;
        sfxAudioSource.PlayOneShot(deathSound);
        animator.SetBool("dead", true);
        animatorFunctions.EmitParticlesDeath();
        yield return new WaitForSeconds(2);
        LoadLevel("Level1");
    }

    public IEnumerator FreezeEffect(float length, float timeScale)
    {
        Time.timeScale = timeScale;
        yield return new WaitForSeconds(length);
        Time.timeScale = 1;
    }

    public void LoadLevel(string loadSceneString)
    {
        animator.SetBool("dead", false);
        health = 100;
        coinsCollected = 0;
        RemoveInventoryItem("none", true);
        GameManager.Instance.frozen = false;
        SceneManager.LoadScene(loadSceneString);
        SetSpawnPosition();
        UpdateUI();
    }

    //Function triggered from Collectables
    public void AddInventoryItem(string inventoryName, Sprite image)
    {
        inventory.Add(inventoryName, image);
        //the blank sprite should now swap with the key sprite
        GameManager.Instance.inventoryItemImage.sprite = inventory[inventoryName];
    }

    //Function triggered from Collectables
    public void RemoveInventoryItem(string inventoryName, bool removeAll = false)
    {
        if (!removeAll)
        {
            inventory.Remove(inventoryName);
        }
        else
        {
            inventory.Clear();
        }
        GameManager.Instance.inventoryItemImage.sprite = inventoryItemBlank;
    }

    public void HurtPlayer(int attackPower, int targetSide)
    {
        StartCoroutine(FreezeEffect(0.1f, 0.5f));
        animator.SetTrigger("hurt");
        launch = -targetSide * launchPower.x;
        velocity.y = launchPower.y;
        cameraEffects.Shake(5, 0.5f);
        health -= attackPower;
        UpdateUI();
    }

    public void IncreaseHealth(int healthIncrease)
    {
        health += healthIncrease;
        if (health > maxHealth)
        { health = maxHealth; }
        UpdateUI();
    }

    public void IncreaseEnergy(int energyIncrease)
    {
        energy += energyIncrease;
        if (energy > maxEnergy)
        { energy = maxEnergy; }
        UpdateUI();
    }

}
